# aCollapTable 1.0.4
It's a simple jQuery plugin for collapsing tables.
Please visit the demo page: http://alvaroveliz.github.io/aCollapTable/
